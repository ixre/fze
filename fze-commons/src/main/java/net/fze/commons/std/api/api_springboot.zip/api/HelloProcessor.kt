package com.tto.qkto.api

import com.line.arch.commons.std.Result
import com.line.arch.commons.std.Types
import com.line.arch.commons.std.api.Context
import com.line.arch.commons.std.api.Processor
import com.line.arch.commons.std.api.Response
import com.tto.qkto.service.BucketService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component

@Component
class HelloProcessor:Processor{
    @Autowired
    lateinit var bucketService: BucketService

    override fun request(fn: String, ctx: Context): Response {
        return when (fn) {
            "say" -> this.say(ctx)
            "fetch_bucket"->this.fetchBucket(ctx)
            else -> Response.RUndefinedApi
        }
    }


    private fun say(ctx: Context): Response {
        var name = Types.valueOrDefault(ctx.form().getString("name"), "nobody")
        return Response.success("hello ${name}")
    }

    /**
     * @api {post} /bucket/fetch 获取bucket结果服务
     * @apiName fetch_bucket
     * @apiGroup hello
     * @apiParam {Int} bucket_hash 哈希值
     * @apiSuccess {String} file_url 文件链接
     * @apiSuccess {String} expires_time 文件有效时间
     * @apiSuccessExample Success-Response
     * {"code":0,"message":"","data":{"hash":"fsgwilsjdl","folder":"0",
     * "file_url":"http://xxxxx.com/files/3/12334342.docx","exipres_time":"1592390232"}}
     * @apiSuccessExample Error-Response
     * {"code":1,"message":"bucket not finished"}
     */
    private fun fetchBucket(ctx: Context): Response {
        val hash = ctx.form().getString("bucket_hash")
        if (hash.isEmpty()) {
            return Response.create(1, "参数不正确:bucket_hash")
        }
        val bucket = this.bucketService.getBucket(hash) ?: return Response.create(1, "no such bucket")
        if (bucket.isFinished.toInt() == 0) {
            return Response.create(1, "bucket not finished")
        }
        val mp = mutableMapOf<String, String>()
        mp["hash"] = bucket.hash
        mp["folder"] = bucket.folder
        mp["file_url"] = bucket.fileUrl
        mp["expires_time"] = bucket.expiresTime.toString()
        return Response.success(mp)
    }
}