package com.tto.qkto.api

import com.google.common.base.Strings
import com.line.arch.commons.std.Types
import com.line.arch.commons.std.TypesConv
import com.line.arch.commons.std.api.ApiUtils
import com.line.arch.commons.std.api.Response
import com.line.arch.commons.std.api.ServerMux
import com.line.arch.commons.std.http.HttpClient


class ApiInterceptor {
    companion object{
        private  var registry: MutableMap<String, Any>? = null
        private var debug: Boolean = false

        fun setup(mux: ServerMux, version:String, logPrefix:String) {
            // 注册服务中间件
            this.serviceMiddleware(mux, logPrefix, version, debug!!, "mzl:core")
        }
        // 初始化服务器
        fun configure(debug:Boolean, registry: MutableMap<String, Any>?) {
            // 是否开启调试模式
            this.debug = debug;
            this.registry = registry
        }


        private fun serviceMiddleware(s: ServerMux, prefix: String, ver: String, debug: Boolean, group: String) {
            s.use { ctx ->
                var err:Error? = null
                val prodVer = ctx.form().getString("version")
                if (ApiUtils.compareVersion(prodVer, ver) < 0) {
                     err = Error(String.format(
                        "%d:%s,require version=%s",
                        10095, "api is deprecated", ver
                    ))
                }
                err
            }
            serviceTrace(s, prefix, group, debug)
        }

        private fun serviceTrace(s: ServerMux, prefix: String, group: String, debug: Boolean) {
            if (debug) {
                // 开启调试
                s.Trace()
            }
            // 输出请求信息
            s.use { ctx ->
                val params = ctx.request().parameterMap
                val data = HttpClient.toQuery(params)
                if (debug) {
                    val apiName = ctx.form().getString("\$api_name")
                    println("\n\n" + Strings.repeat("-", 50))
                    println(prefix + " user " + ctx.key() + " calling " + apiName)
                    println("$prefix request data = [ $data ]")
                }
                // 记录服务端请求时间
                ctx.form().set("\$req_param", data)
                ctx.form().set("\$rpc_begin_time", System.currentTimeMillis())
                null
            }

            // 输出响应结果
            s.After { ctx ->
                val form = ctx.form()
                val rsp = form.get("\$api_response") as Response
                val reqTime = TypesConv.toLong(form.get("\$rpc_begin_time"))!!
                // 请求微秒
                val reqMs = TypesConv.toFloat(System.currentTimeMillis() - reqTime) // 请求毫秒
                // 获取响应结果
                val data = Types.toJson(rsp.data)
                // 如果调试，则输出某些信息
                if (debug) {
                    val elapsed = reqMs / 1000
                    val sb = StringBuilder()
                    sb.append(prefix).append("response : ")
                        .append(rsp.code).append(" ")
                        .append(if (rsp.message == null) "" else rsp.message).append(" ")
                        .append(String.format("; elapsed time ：%.4fs ; ", elapsed))
                        .append("result = [").append(data).append("]")
                    println(sb.toString())
                    if (rsp.code == Response.RAccessDenied.code) {
                        println(" sign not match")
                    }
                }
                // 记录请求日志
                var priority = 0 // 设置优先级,超过500毫秒的请求，优先级标记为3
                if (reqMs > 5000) {
                    priority = 1
                } else if (reqMs > 3000) {
                    priority = 2
                } else if (reqMs > 1000) {
                    priority = 3
                }
                null
            }
        }
    }

}