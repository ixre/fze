package com.tto.qkto.api

import com.line.arch.commons.std.api.Context
import com.line.arch.commons.std.api.ContextFactory
import com.line.arch.commons.std.api.CredentialFunc
import com.line.arch.commons.std.api.ServerMux
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.context.annotation.Bean
import org.springframework.stereotype.Component
import org.springframework.stereotype.Service
import javax.annotation.Resource
import javax.inject.Singleton

@Service
@Singleton
class ApiServer {
    var mux: ServerMux
    var locker: Int = 0

    constructor() {
        val factory = ContextFactory.build(mutableMapOf())
        // 创建服务
        this.mux = ServerMux.New(factory, CredentialFunc { ctx, key -> this.mzlApiSwapFunc(ctx, key) })
        // 添加拦截器
        ApiInterceptor.setup(this.mux, "1.0.0", "[ API][ CORE]:");
    }

    @Resource
    lateinit var helloProcessor: HelloProcessor

    fun init() {
        if (this.locker == 0) {
            synchronized(this.locker) {
                println("----------inited")
                this.locker = 1
                this.mux.register("hello", helloProcessor)
            }
        }
    }

    private fun mzlApiSwapFunc(ctx: Context, key: String): CredentialFunc.Pair {
        return if (key == "80line365mzl141901") {
            CredentialFunc.Pair(1, "239d2d9fb16dbe18d81c54d1764bd33b")
        } else CredentialFunc.Pair(0, "")
    }
}