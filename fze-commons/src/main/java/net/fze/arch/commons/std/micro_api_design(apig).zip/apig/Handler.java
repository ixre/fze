package com.line.arch.commons.std.apig;

import java.util.Map;

/**
 * 处理器
 */
public interface Handler {
    /**
     * 处理请求
     */
    Response process(String fn, Map<String, String> params) throws Throwable;

    /**
     * 接口处理方法
     */
    interface Func {
        Object call(Map<String, String> params) throws Throwable;
    }
}
