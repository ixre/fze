package com.line.arch.commons.std.apig;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.line.arch.commons.std.Types;
import com.line.arch.commons.std.TypesConv;
import com.line.arch.commons.std.api.ApiUtils;
import com.line.arch.commons.std.http.HttpClient;

import java.lang.reflect.Type;
import java.util.Map;

/**
 * API客户端
 */
@Deprecated
public class ApiCli {
    private String _apiUrl = "";
    private String _key = "";
    private String _secret = "";
    private String _signType = "";
    private int _timeout = 0;

    public ApiCli(String apiUrl, String key, String secret, String signType, int timeout) {
        this._apiUrl = apiUrl;
        this._key = key;
        this._secret = secret;
        this._signType = signType;
        this._timeout = timeout;
    }

    /**
     * 调用接口
     *
     * @param apiName 接口名称
     * @param params  参数
     * @return 响应
     */
    public Response call(String apiName, Map<String, String> params) {
        try {
            String ret = new String(this.request(apiName, params));
            if (ret.startsWith("#")) {
                return this.errRsp(ret);
            }
            return new Gson().fromJson(new String(ret), Response.class);
        } catch (Throwable ex) {
            ex.printStackTrace();
            return Response.create(-1, ex.getMessage());
        }
    }

    private Response errRsp(String ret) {
        ret = ret.substring(1);
        int i = ret.indexOf('#');
        int code = TypesConv.toInt(ret.substring(0, i));
        String message = ret.substring(i + 1);
        return Response.create(code, message);
    }

    private DeserizeResponse errDesRsp(String ret) {
        ret = ret.substring(1);
        int i = ret.indexOf('#');
        int code = TypesConv.toInt(ret.substring(1, i));
        String message = ret.substring(i + 2);
        DeserizeResponse d = new DeserizeResponse();
        d.code = code;
        d.message = message;
        return d;
    }

    /**
     * 请求接口，返回原始内容
     *
     * @param apiName 接口名称
     * @param params  参数
     * @return 响应字节
     */
    public byte[] request(String apiName, Map<String, String> params) throws Exception {
        Map<String, String> data = Types.cloneMap(params);
        data.put("api", apiName);
        data.put("version", "1.0");
        data.put("key", this._key);
        data.put("sign_type", this._signType);
        data.put("sign", ApiUtils.Sign(this._signType, data, this._secret));
        String query = HttpClient.toQuery(data);
        return HttpClient.request(this._apiUrl, "POST", query.getBytes(), this._timeout);
    }

    /**
     * 支持泛型的调用接口
     *
     * @param apiName 接口名称
     * @param params  参数
     * @return 响应
     */
    public <T> DeserizeResponse<T> decall(String apiName, Map<String, String> params, Class<T> classOfT) {
        try {
            String ret = new String(this.request(apiName, params));
            if (ret.startsWith("#")) {
                return this.errDesRsp(ret);
            }
            Type gt = TypeToken.getParameterized(DeserizeResponse.class, new Type[]{classOfT}).getType();
            return new Gson().fromJson(ret, gt);
        } catch (Throwable ex) {
            ex.printStackTrace();
            DeserizeResponse<T> d = new DeserizeResponse<>();
            d.code = -100;
            d.message = ex.getMessage();
            return d;
        }
    }
}
