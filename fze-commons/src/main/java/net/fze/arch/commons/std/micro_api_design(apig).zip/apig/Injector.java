package com.line.arch.commons.std.apig;

/**
 * 依赖注入器
 */
public interface Injector {
    /**
     * 获取实例
     */
    <T> T getInstance(Class<T> c);
}
