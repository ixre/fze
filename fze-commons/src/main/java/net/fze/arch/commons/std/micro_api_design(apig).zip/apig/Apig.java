package com.line.arch.commons.std.apig;

import com.google.gson.Gson;
import com.line.arch.commons.std.Types;
import com.line.arch.commons.std.api.ApiUtils;

import java.util.HashMap;
import java.util.Map;

public class Apig {
    public Map<String, Handler> processors = new HashMap<>();
    private String apiKey;
    private String apiSecret;

    public Apig(String apiKey, String apiSecret) {
        this.apiKey = apiKey;
        this.apiSecret = apiSecret;
    }

    /**
     * 处理多个接口方法
     */
    public static Response handleMultiFunc(String fn, Map<String, String> params, Map<String, Handler.Func> funcMap) throws Throwable {
        if (funcMap.containsKey(fn)) {
            Object obj = funcMap.get(fn).call(params);
            if (obj instanceof Response) {
                return (Response) obj;
            }
            return Response.create(0, "").setData(obj);
        }
        return Response.RUndefinedApi;
    }

    /**
     * 注册处理器
     */
    public void register(String name, Handler p) {
        processors.put(name, p);
    }

    /**
     * 处理接口请求
     */
    public byte[] handle(Map<String, String> params) {
        Response rsp = this.checkApi(params);
        if (rsp == null) {
            String apiName = params.get("api");
            String[] arr = apiName.split("\\.");
            if (arr.length != 2) {
                return this.byteRsp(Response.create(10096, "参数不正确:api,如:user.login"));
            }
            if (!this.processors.containsKey(arr[0])) {
                return this.byteRsp(Response.RUndefinedApi);
            }
            try {
                rsp = this.processors.get(arr[0]).process(arr[1], params);
            } catch (Throwable ex) {
                ex.printStackTrace();
                return this.byteRsp(Response.create(Response.RInternalError.code, ex.getMessage()));
            }
        }
        return this.byteRsp(rsp);
    }

    /**
     * 处理接口请求
     */
    @Deprecated
    public byte[] handleV1(Map<String, String> params) {
        Response rsp = this.checkApi(params);
        if (rsp == null) {
            String apiName = params.get("api");
            String[] arr = apiName.split("\\.");
            if (arr.length != 2) {
                return this.byteRsp1(Response.create(10096, "参数不正确:api,如:user.login"));
            }
            if (!this.processors.containsKey(arr[0])) {
                return this.byteRsp1(Response.RUndefinedApi);
            }
            try {
                rsp = this.processors.get(arr[0]).process(arr[1], params);
            } catch (Throwable ex) {
                ex.printStackTrace();
                return this.byteRsp1(Response.create(Response.RInternalError.code, ex.getMessage()));
            }
        }
        return this.byteRsp1(rsp);
    }

    private byte[] byteRsp1(Response response) {
        return new Gson().toJson(response).getBytes();
    }

    private byte[] byteRsp(Response response) {
        if (response.code != 0 && response.code != 10000) {
            return String.format("#%d#%s", response.code, response.message).getBytes();
        }
        if (response.data == null) {
            return new byte[]{'{', '}'};
        }
        return new Gson().toJson(response.data).getBytes();
    }

    /**
     * 检测API接口
     */
    private Response checkApi(Map<String, String> params) {
        String key = params.get("key");
        String sign = params.get("sign");
        String signType = params.get("sign_type");
        // 验证是否传递Key和Sign
        if (Types.emptyOrNull(key) || Types.emptyOrNull(sign) || Types.emptyOrNull(signType)) {
            return Response.RIncorrectApiParams;
        }
        // 验证接口用户是否正确
        if (!key.equals(this.apiKey)) {
            return Response.RAccessDenied;
        }
        String resign = ApiUtils.Sign(signType, params, this.apiSecret);
        if (!sign.equals(resign)) { // 判断签名是否正确
            return Response.RAccessDenied;
        }
        return null;
    }

    /**
     * 配置接口
     */
    public void configure(Configuration r, Injector injector) {
        r.configure(this, injector);
    }
}
