## HTTP API 网关

```
  Request apiReq = new Request(apiKey, apiSecret);
  apiReq.configure(ApiV1::init, ctx.injector::getInstance);
  return this.apiReq.handle(new HashMap<>());
  
  
  public class ApiV1 {
      public static void init(Request request, Injector injector) {
          request.register("sample", injector.get(SampleProcessor.class));
      }
  }
  
  public class SampleProcessor implements Processor {
      @Override
      public Response process(String fn, Map<String, String> params) {
          if (fn.equals("hello")) {
              return this.hello(params);
          }
          return Response.RErrUndefinedApi;
      }
  
      /**
       * @api {post} #sample.hello 问好服务
       * @apiName hello
       * @apiGroup sample
       * @apiParam {String} name 姓名，默认为:nobody
       * @apiSuccess {Int} time 服务器UNIX时间
       * @apiSuccessExample 成功
       * {"code":0,"message":"hello jarrysix","data":{"time":1531450335}}
       * @apiSuccessExample 失败
       * {"code":1,"message":"access denied"}
       */
      private Response hello(Map<String, String> params) {
          String n = params.get("name");
          if (Types.emptyOrNull(n)) {
              n = "nobody";
          }
          return Response.create(0, "hello " + n)
                  .setData(Map.of("time", new Date().getTime() / 1000));
      }
  }
  
```