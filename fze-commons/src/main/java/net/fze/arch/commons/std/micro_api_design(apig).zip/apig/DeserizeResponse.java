package com.line.arch.commons.std.apig;

import com.google.gson.annotations.SerializedName;

/**
 * 反序列化响应
 */
public class DeserizeResponse<T> {
    /**
     * 代码
     */
    @SerializedName("Code")
    public int code;

    /**
     * 消息
     */
    @SerializedName("Message")
    public String message;

    /**
     * 数据
     */
    @SerializedName("Data")
    public T data;
}
