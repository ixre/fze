package com.line.arch.commons.std.apig;


/**
 * 处理器处理器
 */

public interface Configuration {
    void configure(Apig req, Injector injector);
}
